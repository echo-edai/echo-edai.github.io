# Coral NPU 微架构教学练习包

这是独立教学原型，并非上游 Coral RTL。

需要 Node.js 与 Icarus Verilog。在解压目录运行：

```sh
node tools/test_learning_models.cjs
python3 tools/test_learning_rtl.py
node tools/crosscheck_learning_models.cjs
```

接口和范围见 rtl/README.md。测试记录写入 research/。
test_coral_models.cjs 包含额外的源码基线核对；完整运行该项需要原始 authoring 工作区，见脚本说明。
