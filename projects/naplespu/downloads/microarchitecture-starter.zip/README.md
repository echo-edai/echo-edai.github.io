# 微架构教学 RTL 练习包

从解压目录运行：

    python3 web/tools/test_learning_rtl.py
    node web/tools/test_learning_models.cjs
    node web/tools/crosscheck_learning_models.cjs

RTL测试需要已安装iverilog/vvp；浏览器模型测试需要Node.js。
该包仅含独立教学原型，不含完整NaplesPU上游源码。详见web/rtl/README.md。
