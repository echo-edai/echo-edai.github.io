# Gemmini independent learning prototypes

Run `python3 rtl/run.py` (Icarus required) and `node tools/test_models.cjs`.
See rtl/README.md for interfaces, scope and MIT license. These are not upstream Gemmini RTL and the browser algorithms are not cycle-equivalent to these prototypes.
