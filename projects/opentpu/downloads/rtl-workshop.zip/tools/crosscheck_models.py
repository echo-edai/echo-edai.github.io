#!/usr/bin/env python3
"""Cross-check original teaching RTL against the site's JS models, never upstream RTL."""
import hashlib
import json
from pathlib import Path
import random
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent.parent
SEED = 0x4F545055
RANDOM_CYCLES = 1200
FIELDS = ["reset", "iv", "or", "data", "issue", "reads", "writes", "complete",
          "reqValid", "client", "getm", "ack", "rspReady", "cx", "cy", "dx", "dy"]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(command, cwd=None):
    result = subprocess.run(command, cwd=cwd, text=True, capture_output=True, timeout=60)
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)
    return result

for executable in ("node", "iverilog", "vvp"):
    if not shutil.which(executable):
        raise SystemExit("Missing required executable: " + executable)

# Prefix deliberately exercises held responses, delayed/wrong target ACK and FIFO boundaries.
prefix = [
    {"reset": 1},
    {"iv": 1, "data": 17, "issue": 1, "writes": 4, "reqValid": 1, "client": 0},
    {"iv": 1, "data": 34, "issue": 1, "reads": 4, "writes": 8},
    {"iv": 1, "data": 51, "rspReady": 1},
    {"iv": 1, "or": 1, "data": 51, "reqValid": 1, "client": 1},
    {"iv": 1, "or": 1, "data": 68, "rspReady": 1, "complete": 4},
    {"or": 1, "reqValid": 1, "client": 0, "getm": 1, "issue": 1, "reads": 4, "writes": 8},
    {"ack": 1, "reqValid": 1, "client": 1},
    {"ack": 0, "rspReady": 1},
    {"ack": 2},
    {"reqValid": 1, "client": 1, "getm": 1},
    {"rspReady": 1, "complete": 8},
    {"reqValid": 1, "client": 1},
    {"ack": 0},
    {"ack": 1},
    {"rspReady": 1},
    {"reset": 1},
]
raw = [{**dict.fromkeys(FIELDS, 0), **row} for row in prefix]
rng = random.Random(SEED)
for _ in range(RANDOM_CYCLES):
    raw.append({
        "random": True, "reset": int(rng.randrange(57) == 0),
        "iv": rng.randrange(2), "or": rng.randrange(2), "data": rng.randrange(256),
        "issue": rng.randrange(2), "reads": rng.randrange(256), "writes": rng.randrange(256),
        "complete": rng.randrange(256), "reqValid": int(rng.randrange(4) != 0),
        "client": rng.randrange(2), "getm": rng.randrange(2), "ack": rng.randrange(4),
        "rspReady": int(rng.randrange(4) != 0), "cx": rng.randrange(4), "cy": rng.randrange(4),
        "dx": rng.randrange(4), "dy": rng.randrange(4),
    })

# Observable combinational outputs before the edge, followed by state/outputs after the edge.
# Data is compared only when valid, normalized to zero otherwise.
PRE = {
    "fifoReadyPre": "ir", "fifoValidPre": "ov", "fifoDataPre": "(ov ? odata : 0)",
    "fifoPut": "(iv && ir)", "fifoPop": "(ordy && ov)", "scoreReadyPre": "issue_ready",
    "dirReadyPre": "rq_ready", "dirProbePre": "probes", "dirProbeSharedPre": "probe_shared",
    "dirRspValidPre": "rsp_v", "dirRspClientPre": "rsp_c", "dirRspModifiedPre": "rsp_m",
    "xy": "port",
}
POST = {
    "fifoCount": "count", "fifoReadyPost": "ir", "fifoValidPost": "ov",
    "fifoDataPost": "(ov ? odata : 0)", "scoreBusy": "busy_regs", "scoreReadyPost": "issue_ready",
    "dirState": "dir_state", "dirSharers": "sharers", "dirOwner": "dir_owner",
    "dirBusy": "dir_busy", "dirPending": "dut_dir.pending",
    "dirTargetState": "dut_dir.target_state", "dirTargetSharers": "dut_dir.target_sharers",
    "dirTargetOwner": "dut_dir.target_owner", "dirTransactionClient": "dut_dir.transaction_client",
    "dirTransactionGetm": "dut_dir.transaction_getm", "dirRspValidPost": "rsp_v",
    "dirRspClientPost": "rsp_c", "dirRspModifiedPost": "rsp_m", "dirReadyPost": "rq_ready",
    "dirProbePost": "probes", "dirProbeSharedPost": "probe_shared",
}
NAMES = list(PRE) + list(POST)

NODE_REFERENCE = r"""
'use strict';
const fs=require('node:fs'), M=require(process.argv[2]);
const raw=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));
let f=M.fifoInit(),d=M.directoryInit(),b=0,held=null;
const vectors=[],trace=[];
function dirOut(s,i,suffix) {
  return Object.fromEntries([
    ['dirReady'+suffix,!i.reset&&!s.busy&&!s.rspValid],
    ['dirProbe'+suffix,!i.reset&&s.busy?s.pending:0],
    ['dirProbeShared'+suffix,s.busy&&!s.getm],
    ['dirRspValid'+suffix,s.rspValid],['dirRspClient'+suffix,s.rspClient],
    ['dirRspModified'+suffix,s.rspModified]
  ].map(([k,v])=>[k,Number(v)]));
}
for(const rawInput of raw) {
  const i={...rawInput};
  // For random traffic, hold request identity/payload until it is accepted.
  // Completions are restricted to existing busy producers; random ACKs to pending targets.
  if(i.random) {
    if(i.reset) held=null;
    else if(!held&&i.reqValid) held={client:i.client,getm:i.getm};
    i.reqValid=Number(!i.reset&&!!held);
    i.client=held?held.client:0;i.getm=held?held.getm:0;
    i.complete &= b;
    i.ack &= d.pending;
    if(i.reqValid&&!d.busy&&!d.rspValid) held=null;
  }
  delete i.random;
  const fr=M.fifoStep(f,i),dr=M.directoryStep(d,i),sr=M.scoreboardStep(b,i.reads,i.writes,i.complete,!!i.issue);
  const pre={fifoReadyPre:Number(fr.ready),fifoValidPre:Number(fr.valid),
    fifoDataPre:fr.valid?f.q[0]:0,fifoPut:Number(fr.put),fifoPop:Number(fr.pop),
    scoreReadyPre:Number(!i.reset&&sr.ready),...dirOut(d,i,'Pre'),xy:M.route(i.cx,i.cy,i.dx,i.dy)};
  const bn=i.reset?0:sr.busy;
  const post={fifoCount:fr.state.q.length,fifoReadyPost:Number(!i.reset&&fr.state.q.length<2),
    fifoValidPost:Number(!i.reset&&fr.state.q.length>0),fifoDataPost:!i.reset&&fr.state.q.length?fr.state.q[0]:0,
    scoreBusy:bn,scoreReadyPost:Number(!i.reset&&M.scoreboardStep(bn,i.reads,i.writes,0,false).ready),
    dirState:dr.state,dirSharers:dr.sharers,dirOwner:dr.owner,dirBusy:Number(dr.busy),
    dirPending:dr.pending,dirTargetState:dr.targetState,dirTargetSharers:dr.targetSharers,
    dirTargetOwner:dr.targetOwner,dirTransactionClient:dr.client,dirTransactionGetm:Number(dr.getm),
    ...dirOut(dr,i,'Post')};
  vectors.push(i);trace.push({...pre,...post});f=fr.state;d=dr;b=bn;
}
fs.writeFileSync(process.argv[4],JSON.stringify(vectors));
fs.writeFileSync(process.argv[5],JSON.stringify(trace));
"""

input_scan = "rst,iv,ordy,idata,issue,reads,writes,complete,rq,client,getm,ack,rsp_r,cx,cy,dx,dy"
TB_START = r"""
`timescale 1ns/1ps
module tb_cross;
reg clk=0;always #5 clk=~clk;
reg rst=1,iv=0,ordy=0;reg [7:0] idata=0;
wire ir,ov;wire [7:0] odata;wire [1:0] count;
learn_elastic dut_fifo(clk,rst,iv,ir,idata,ov,ordy,odata,count);
reg issue=0;reg [7:0] reads=0,writes=0,complete=0;
wire issue_ready;wire [7:0] busy_regs;
learn_scoreboard dut_sb(clk,rst,issue,reads,writes,complete,issue_ready,busy_regs);
reg rq=0,client=0,getm=0,rsp_r=0;reg [1:0] ack=0;
wire rq_ready,probe_shared,rsp_v,rsp_c,rsp_m,dir_owner,dir_busy;
wire [1:0] probes,dir_state,sharers;
learn_directory dut_dir(clk,rst,rq,rq_ready,client,getm,probes,probe_shared,ack,
  rsp_v,rsp_r,rsp_c,rsp_m,dir_state,sharers,dir_owner,dir_busy);
reg [1:0] cx=0,cy=0,dx=0,dy=0;wire [2:0] port;
learn_xy_route dut_xy(cx,cy,dx,dy,port);
integer fd,n,k;
"""

with tempfile.TemporaryDirectory(prefix="opentpu-model-crosscheck-") as temp:
    tmp = Path(temp)
    (tmp / "raw.json").write_text(json.dumps(raw))
    (tmp / "reference.cjs").write_text(NODE_REFERENCE)
    run(["node", str(tmp/"reference.cjs"), str(ROOT/"models.js"), str(tmp/"raw.json"),
         str(tmp/"vectors.json"), str(tmp/"expected.json")])
    vectors = json.loads((tmp/"vectors.json").read_text())
    expected = json.loads((tmp/"expected.json").read_text())
    (tmp/"vectors.txt").write_text("\n".join(" ".join(str(int(v[n])) for n in FIELDS) for v in vectors)+"\n")
    tb = TB_START
    tb += "\n".join(f"integer pre_{name};" for name in PRE)
    tb += '\ninitial begin\n @(posedge clk);#1;\n fd=$fopen("vectors.txt","r");\n'
    tb += ' if(fd==0) $fatal(1,"vectors open failed");\n k=0;\n'
    tb += f" repeat ({len(vectors)}) begin\n @(negedge clk);\n"
    tb += f' n=$fscanf(fd,"{" ".join(["%d"]*len(FIELDS))}\\n",{input_scan});\n'
    tb += f' if(n!={len(FIELDS)}) $fatal(1,"vector field count");\n #1;\n'
    tb += "\n".join(f" pre_{name}={expression};" for name, expression in PRE.items())
    tb += "\n @(posedge clk);#1;\n"
    display_values = ["k"] + ["pre_" + name for name in PRE] + list(POST.values())
    tb += f' $display("TRACE,{",".join(["%0d"]*len(display_values))}",{",".join(display_values)});\n'
    tb += ' k=k+1;\n end\n $fclose(fd);$finish;\nend\ninitial begin #1000000;$fatal(1,"watchdog");end\nendmodule\n'
    (tmp/"tb_cross.sv").write_text(tb)
    rtl_names = ["learn_elastic.sv", "learn_xy_route.sv", "learn_scoreboard.sv", "learn_directory.sv"]
    sources = [ROOT/"rtl"/name for name in rtl_names]
    compiled = run(["iverilog", "-g2012", "-Wall", "-s", "tb_cross", "-o", "cross.vvp",
                    *map(str, sources), "tb_cross.sv"], cwd=tmp)
    simulated = run(["vvp", "cross.vvp"], cwd=tmp)
    actual = []
    for line in simulated.stdout.splitlines():
        if line.startswith("TRACE,"):
            values = list(map(int, line.split(",")[1:]))
            if len(values) != len(NAMES)+1:
                raise AssertionError("trace field count")
            if values[0] != len(actual):
                raise AssertionError("trace sequence index")
            actual.append(dict(zip(NAMES,values[1:])))
    if len(actual) != len(expected):
        raise AssertionError(f"trace length: {len(actual)} versus {len(expected)}")
    comparisons = 0
    for cycle, (want, got) in enumerate(zip(expected, actual)):
        for name in NAMES:
            comparisons += 1
            if got[name] != want[name]:
                raise AssertionError(json.dumps({"cycle":cycle,"field":name,"model":want[name],
                    "rtl":got[name],"input":vectors[cycle]},ensure_ascii=False))
    model_checks = json.loads(run(["node", str(ROOT/"tools"/"check_models.cjs")]).stdout)
    version = run(["iverilog", "-V"]).stdout.splitlines()[0]
    result = {
        "passed": True,
        "scope": "Original teaching RTL and browser models only; no upstream openTPU RTL tested",
        "seed": hex(SEED), "directed_cycles":len(prefix), "random_cycles":RANDOM_CYCLES,
        "cycles":len(vectors), "fields_per_cycle":len(NAMES), "field_comparisons":comparisons,
        "matched_models":["two-entry synchronous FIFO","4x4 XY next-hop function",
                          "8-register busy-mask scoreboard","two-client single-line control directory"],
        "sampling":"Input combinational handshakes before rising edge; state and outputs after edge; invalid FIFO data ignored",
        "scoreboard_reset":"JS function has no reset input: outer driver applies synchronous busy=0 and reset-gates ready, matching RTL",
        "traffic":"Fixed seeded input; random directory request payload held until accepted, random completions restricted to busy producers, random ACK mask restricted to pending probes; directed prefix also checks an unrelated ACK",
        "simulator":version,"compile_stderr":compiled.stderr,
        "sources":[{"path":str(p.relative_to(ROOT)),"sha256":digest(p)}
                   for p in [ROOT/"models.js",*sources,ROOT/"tools"/"check_models.cjs",Path(__file__).resolve()]],
        "input_vectors_sha256":digest(tmp/"vectors.txt"),
        "compared_fields":NAMES, "contract_checks":model_checks,
        "limitations":["Finite trace equivalence, not formal proof",
                       "Default module parameters only; XY coordinates restricted to 4x4",
                       "Directory has no address/data/cache clients or network, ACK identity assumed",
                       "Quantization checks ideal math for finite nonempty vectors, not openTPU floating-point/RTL precision",
                       "No synthesis, timing or CDC analysis"],
    }
    destination = ROOT/"research"/"model-crosscheck.json"
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps({"passed":True,"cycles":len(vectors),"field_comparisons":comparisons,
                      "contract_assertions":model_checks["assertions"],"report":"research/model-crosscheck.json"},indent=2))
