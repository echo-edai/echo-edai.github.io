#!/usr/bin/env node
'use strict';
// Independent contract/invariant checks for the site's original teaching models.
// These are not openTPU ISA/RTL tests.
const assert = require('node:assert/strict');
const M = require('../models.js');
let checks = 0;
const groups = {};
function check(group, condition, message) {
  assert.ok(condition, `${group}: ${message}`);
  checks++; groups[group] = (groups[group] || 0) + 1;
}
function eq(group, actual, expected, message) {
  assert.deepEqual(actual, expected, `${group}: ${message}`);
  checks++; groups[group] = (groups[group] || 0) + 1;
}
let seed = 0x71f0a35c;
function random() {
  seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5;
  return seed >>> 0;
}

// FIFO acceptance history is checked independently of its internal queue.
let f = M.fifoInit(), accepted = [], retired = [], sent = 0;
for (let k=0; k<1000; k++) {
  const r=random(), i={iv:!!(r&1), or:!!(r&2), data:(r>>>8)&255};
  const before = JSON.stringify(f), oldCount=accepted.length-retired.length;
  const n=M.fifoStep(f,i);
  eq('fifo', JSON.stringify(f), before, 'step must not mutate its input');
  eq('fifo', n.ready, oldCount<2, 'ready uses old occupancy');
  eq('fifo', n.valid, oldCount>0, 'valid uses old occupancy');
  if(n.put) {accepted.push(i.data);sent++;}
  if(n.pop) {eq('fifo',n.output,accepted[retired.length],'retire oldest accepted item');retired.push(n.output);}
  eq('fifo',n.state.q.length,accepted.length-retired.length,'occupancy conserves accepted minus retired');
  check('fifo',n.state.q.length>=0&&n.state.q.length<=2,'bounded occupancy');
  f=n.state;
}
while(f.q.length) {const n=M.fifoStep(f,{iv:false,or:true});eq('fifo',n.output,accepted[retired.length],'drain order');retired.push(n.output);f=n.state;}
eq('fifo',retired,accepted,'accepted sequence is reproduced exactly');
const full={q:[1,2],cycle:3}, fullExchange=M.fifoStep(full,{iv:true,or:true,data:3});
eq('fifo',fullExchange.put,false,'full FIFO does not accept a same-edge replacement');
eq('fifo',fullExchange.state.q,[2],'full pop frees a slot for next cycle');
eq('fifo',M.fifoStep(full,{reset:true}).state,M.fifoInit(),'reset drops held items');

// All coordinate pairs: every hop reduces distance, never leaves the mesh, finishes X first.
for(let x=0;x<4;x++) for(let y=0;y<4;y++) for(let dx=0;dx<4;dx++) for(let dy=0;dy<4;dy++) {
  const p=M.xyPath(x,y,dx,dy), distance=Math.abs(x-dx)+Math.abs(y-dy);
  eq('xy',p.length,distance+1,'shortest path length');
  eq('xy',p[p.length-1],[dx,dy],'path ends at destination');
  for(let k=1;k<p.length;k++) {
    const [cx,cy]=p[k-1], [nx,ny]=p[k];
    check('xy',nx>=0&&nx<4&&ny>=0&&ny<4,'all hops in mesh');
    eq('xy',Math.abs(nx-dx)+Math.abs(ny-dy),Math.abs(cx-dx)+Math.abs(cy-dy)-1,'Manhattan distance falls by one');
    if(cx!==dx) eq('xy',ny,cy,'horizontal dimension completes first');
  }
  eq('xy',M.route(dx,dy,dx,dy),0,'destination ejects locally');
}

// The simple register scoreboard intentionally has no same-cycle completion bypass.
eq('scoreboard',M.scoreboardStep(4,4,8,4),{ready:false,busy:0},'completion does not bypass old RAW hazard');
eq('scoreboard',M.scoreboardStep(4,0,4,0),{ready:false,busy:4},'WAW blocks');
eq('scoreboard',M.scoreboardStep(4,1,16,0),{ready:true,busy:20},'independent issue reserves destination');
eq('scoreboard',M.scoreboardStep(0,0,4,0,false),{ready:true,busy:0},'valid low never reserves');
for(let k=0;k<1000;k++) {
  const b=random()&255,r=random()&255,w=random()&255,c=(random()&255)&b,v=!!(random()&1);
  const n=M.scoreboardStep(b,r,w,c,v);
  check('scoreboard',Number.isInteger(n.busy)&&n.busy>=0&&n.busy<=255,'8-bit busy mask');
  if((b&r)||(b&w)) eq('scoreboard',n.ready,false,'reserved source or destination blocks');
  if(!v||!n.ready) eq('scoreboard',n.busy,b&~c,'only completed producers may clear state');
  if(v&&n.ready) check('scoreboard',(n.busy&w)===w,'accepted destinations stay reserved');
}

// Directory properties cover stable metadata, bounded masks, held response and no early grant.
let d=M.directoryInit(), acceptedDir=0, responded=0;
let held=null;
for(let k=0;k<2000;k++) {
  const r=random();
  if(!held&&(r&3)!==0) held={client:(r>>>4)&1,getm:!!(r&32)};
  const i={reqValid:!!held,client:held?held.client:0,getm:held?held.getm:false,
    ack:(r>>>8)&3,rspReady:!!(r&64)};
  const wasReady=!d.busy&&!d.rspValid;
  if(i.reqValid&&wasReady) {acceptedDir++;held=null;}
  if(d.rspValid&&i.rspReady) responded++;
  const old=JSON.stringify(d),n=M.directoryStep(d,i);
  eq('directory',JSON.stringify(d),old,'step does not mutate input');
  check('directory',[0,1,2].includes(n.state),'only U/S/M stable metadata');
  check('directory',n.sharers>=0&&n.sharers<=3&&n.pending>=0&&n.pending<=3,'two-client masks bounded');
  if(n.state===0) eq('directory',n.sharers,0,'U has no sharers');
  if(n.state===1) check('directory',n.sharers!==0,'S has at least one sharer');
  if(n.state===2) {eq('directory',n.sharers,0,'M uses owner, no shared readers');check('directory',n.owner===0||n.owner===1,'one owner identity');}
  check('directory',!(n.busy&&n.rspValid),'response cannot precede probe completion');
  if(d.busy) {
    eq('directory',n.pending,d.pending&~i.ack,'only acknowledged pending targets clear');
    if(n.pending!==0) {eq('directory',[n.state,n.sharers,n.owner],[d.state,d.sharers,d.owner],'metadata stable while ACK missing');eq('directory',n.rspValid,false,'missing ACK prevents grant');}
  }
  if(d.rspValid&&!i.rspReady) eq('directory',[n.rspValid,n.rspClient,n.rspModified],[true,d.rspClient,d.rspModified],'response held until consumed');
  check('directory',responded<=acceptedDir,'no unsolicited completion');
  check('directory',acceptedDir-responded<=1,'at most one outstanding transaction');
  d=n;
}
eq('directory',M.directoryStep(d,{reset:true}),M.directoryInit(),'reset clears transaction and response');

// Quantization is an ideal mathematical demo, not a bit-accurate RTL model.
const ties=[[-3.5,-4],[-2.5,-2],[-1.5,-2],[-.5,0],[.5,0],[1.5,2],[2.5,2],[3.5,4]];
for(const [x,y] of ties) eq('round-even',M.roundEven(x),y,`tie ${x}`);
for(const x of [-5,-1,0,1,7]) eq('round-even',M.roundEven(x),x,'integers unchanged');
eq('round-even',M.roundEven(1.5-Number.EPSILON),1,'just below positive tie');
eq('round-even',M.roundEven(1.5+Number.EPSILON),2,'just above positive tie');
eq('round-even',M.roundEven(-1.5-Number.EPSILON),-2,'just below negative tie');
eq('round-even',M.roundEven(-1.5+Number.EPSILON),-1,'just above negative tie');
const zero=M.quantize([0,0,0]);
eq('quant',zero.scale,1,'zero vector gets finite unit scale');
eq('quant',zero.q,[0,0,0],'zero codes');eq('quant',zero.restored,[0,0,0],'zero restoration');eq('quant',zero.maxError,0,'zero error');
const edge=M.quantize([-127,0,127]);eq('quant',edge.q,[-127,0,127],'signed endpoints');eq('quant',edge.maxError,0,'exact endpoint reconstruction');
for(let k=0;k<200;k++) {
  const values=Array.from({length:8},()=>((random()%200001)-100000)/1000),q=M.quantize(values);
  check('quant',Number.isFinite(q.scale)&&q.scale>0,'positive finite scale for finite nonempty input');
  check('quant',q.q.every(x=>Number.isInteger(x)&&Math.abs(x)<=127),'integer bounded codes');
  check('quant',q.maxError<=q.scale*.50000000001+1e-12,'nearest rounding error bounded by half scale');
}

eq('banks',M.bankArbitrate([0,1,2,3,4,5,6,7],8,1).map(x=>x.granted),Array(8).fill(true),'contiguous addresses spread');
eq('banks',M.bankArbitrate([0,8,16,24],8,1).map(x=>x.granted),[true,false,false,false],'stride conflict');
eq('banks',M.bankArbitrate([0,8,16],8,2).map(x=>x.granted),[true,true,false],'two slots, two winners');
eq('banks',M.bankArbitrate([-1],8,1)[0].bank,7,'normalized modulo');
const A=[[1,2,3],[-1,0,2]],W=[[4,5,6],[1,-1,2]];
eq('matmul',M.matmul(A,W),[[32,5],[8,3]],'dot is A times W transpose');
eq('matmul',M.matmul(A,W,0),[[0,0],[0,0]],'zero accumulated terms');
eq('matmul',M.matmul(A,W,1),[[4,1],[-4,-1]],'one partial term');

const result={passed:true,scope:'Original browser teaching-model contract checks, not upstream openTPU verification',
  seed:'0x71f0a35c',assertions:checks,groups,fifoAccepted:sent,directoryAccepted:acceptedDir,directoryResponded:responded,
  quantizationScope:'Finite nonempty inputs, range 127, ideal real-number rounding; not RTL precision'};
console.log(JSON.stringify(result,null,2));
